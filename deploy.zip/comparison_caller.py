#!/usr/bin/env python3
"""Production caller for Module 3 scope comparison.

Confluence only: required scope is normalized by the production keying function;
carrier scope is the deterministic Carrier Parser Part-B summary; the frozen
comparison oracle assigns the 6-state result. No comparison logic is reimplemented here.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Optional, Sequence

from module3_keying import key_and_normalize
from module3_comparison_oracle import build_comparison
# The ONE authority for narrowing a carrier keyed view to a single structure — the same function
# manual_carrier_entry itself uses when it restricts to one structure, so a per-structure carrier side
# built here is byte-identical in shape and semantics to the single-structure path.
from manual_carrier_entry import _restrict_to_structure
from shared_category_registry import field_category_ids, system_for_field_category   # FRAME v104e: bridge 4 RETIRED at _surface_mixed_scope — no package picked


@dataclass(frozen=True)
class RequiredLineForComparison:
    item: str
    category_id: str
    qty: float
    unit: str
    # v77 DEFECT 5: the label authority ("user-defined" for a user-placed, user-labelled appurtenance).
    # key_and_normalize reads this to tell a user's own label apart from the generic category item so it
    # can group by label. Additive with a default, so every existing caller is unchanged.
    citation: Optional[str] = None
    # FRAME v104d: the line's roof system, carried through. v104c's adapter dropped it, so key_and_normalize's per-line
    # read fell back to the sole package — harmless with one, a RegistryWiringError on every mixed-roof comparison.
    # Additive with a default, so every existing caller is unchanged.
    material_profile_id: Optional[str] = None


def _required_lines_with_item(lines: Iterable[Any]) -> Sequence[RequiredLineForComparison]:
    """Adapt Module 2 aggregate lines to the keying contract by surfacing .item."""
    out = []
    for line in lines:
        category_id = getattr(line, "category_id")
        out.append(RequiredLineForComparison(
            item=getattr(line, "item", None) or category_id,
            category_id=category_id,
            qty=float(getattr(line, "qty")),
            unit=getattr(line, "unit"),
            citation=getattr(line, "citation", None),
            material_profile_id=getattr(line, "material_profile_id", None),   # FRAME v104d
        ))
    return tuple(out)


def _affected_sf(module2_result: Any) -> float:
    for name in ("affected_SF_raw_total", "affected_sf_raw_total", "affected_SF", "affected_sf"):
        if hasattr(module2_result, name):
            return float(getattr(module2_result, name))
    raise ValueError("module2_result missing affected SF total")


def _aggregated_scope(module2_result: Any) -> Iterable[Any]:
    if hasattr(module2_result, "aggregated_scope"):
        return getattr(module2_result, "aggregated_scope")
    if isinstance(module2_result, Mapping) and "aggregated_scope" in module2_result:
        return module2_result["aggregated_scope"]
    raise ValueError("module2_result missing aggregated_scope")


def _aggregated_scope_by_structure(module2_result: Any) -> Sequence[Any]:
    """The per-structure required scope Module 2 already produces: ((structure_id, lines), ...), one
    entry per structure the USER SCOPED (built only from the user's confirmed events, grouped by each
    component's facet). Empty or single-entry for a single-structure roof, so the single-structure path
    below is unchanged."""
    if isinstance(module2_result, Mapping):
        return tuple(module2_result.get("aggregated_scope_by_structure", ()) or ())
    return tuple(getattr(module2_result, "aggregated_scope_by_structure", ()) or ())


def _structure_affected_sf(module2_result: Any) -> Mapping[str, float]:
    raw = (module2_result.get("structure_affected_SF", ()) if isinstance(module2_result, Mapping)
           else getattr(module2_result, "structure_affected_SF", ())) or ()
    return {str(sid): float(sf) for sid, sf in raw}


def _per_system(raw: Any, fallback: Any) -> Any:
    """{system_id: SF} from a ((system_id, SF), ...) tuple — or `fallback` (the claim-level figure) when there is none
    or any area is unattributed (""). With one system the mapping's one value IS the fallback figure (the same
    components, summed in the same order), so key_and_normalize gets today's dual; on a mixed roof the fallback
    reaches key_and_normalize's gate and raises."""
    pairs = [(str(k), float(v)) for k, v in (raw or ())]
    if not pairs or any(k == "" for k, _ in pairs):
        return fallback
    return dict(pairs)


def _system_affected_sf(module2_result: Any) -> Any:
    """FRAME v104d (QA Q1 (a)): the claim's affected SF per roof system, for key_and_normalize's dual."""
    raw = (module2_result.get("system_affected_SF", ()) if isinstance(module2_result, Mapping)
           else getattr(module2_result, "system_affected_SF", ()))
    return _per_system(raw, _affected_sf(module2_result))


def _structure_system_affected_sf(module2_result: Any) -> Mapping[str, Any]:
    """FRAME v104d (QA Q1 (a)): {structure_id: ((system_id, SF), ...)} — each structure's affected SF per roof system."""
    raw = (module2_result.get("structure_system_affected_SF", ()) if isinstance(module2_result, Mapping)
           else getattr(module2_result, "structure_system_affected_SF", ())) or ()
    return {str(sid): v for sid, v in raw}


def _structure_facet_counts(module2_result: Any) -> Mapping[str, int]:
    raw = (module2_result.get("structure_facet_counts", ()) if isinstance(module2_result, Mapping)
           else getattr(module2_result, "structure_facet_counts", ())) or ()
    return {str(sid): int(n) for sid, n in raw}


# ---- v93: TWO-FACET COMPONENTS — the operation comes from the component's OWN two facets ------------------
# Joseph, 2026-10-26: TRANSITION_FLASH (and VALLEY_METAL, "the same") is REPLACE only when BOTH of its facets are
# replaced; one facet replaced and the other repaired OR NOT AFFECTED -> R&R. module2_assembly decides each
# component's operation where its facets are known (RoofAssemblyResult.two_facet_operations); here those votes
# FILL build_comparison's existing `required_operations` hook, which _required_op_ctx already honours FIRST.
# No branch is added to the oracle. Every other category keeps the claim-level is_replacement promotion.
TWO_FACET_CATEGORIES = ("TRANSITION_FLASH", "VALLEY_METAL")


def _two_facet_votes(module2_result: Any) -> Sequence[tuple]:
    raw = (module2_result.get("two_facet_operations", ()) if isinstance(module2_result, Mapping)
           else getattr(module2_result, "two_facet_operations", ())) or ()
    return tuple(tuple(v) for v in raw)


def _two_facet_required_operations(module2_result: Any, structure_id: Optional[str] = None):
    """(required_operations, unresolved) for ONE build_comparison call — the whole roof (structure_id None)
    or one scoped structure. A category resolves only when EVERY one of its components in that scope agrees.
    When they disagree (or a component's facets could not be read) the category is NOT resolved — it is left
    out of required_operations, so it falls back to today's claim-level behaviour (no worse than v92) — and
    it is returned in `unresolved` so the disagreement is SURFACED, never silently picked."""
    by_cat: dict = {}
    for sid, cat, cid, op in _two_facet_votes(module2_result):
        if cat not in TWO_FACET_CATEGORIES:
            continue
        if structure_id is not None and str(sid) != str(structure_id):
            continue
        by_cat.setdefault(cat, []).append((str(cid), op))
    required_operations: dict = {}
    unresolved: dict = {}
    for cat, votes in by_cat.items():
        ops = {op for _cid, op in votes}
        if len(ops) == 1 and None not in ops:
            required_operations[cat] = next(iter(ops))
        else:
            unresolved[cat] = tuple(votes)
    return required_operations, unresolved


def _surface_unresolved(comparison: Mapping[str, Any], unresolved: Mapping[str, Sequence[tuple]]):
    """Mark each comparison line whose two-facet operation was NOT resolved: the components and the operation
    each one would take, and the (claim-level) operation actually used. §5 renders it as an explanation."""
    if not unresolved or not comparison:
        return comparison
    for line in comparison.get("lines", ()) or ():
        cat = line.get("category_id")
        if cat in unresolved:
            line["two_facet_unresolved"] = {
                "components": [{"component_id": cid, "operation": op} for cid, op in unresolved[cat]],
                "operation_used": line.get("required_operation"),
            }
    return comparison


def _surface_mixed_scope(comparison: Mapping[str, Any], scope_lines: Iterable[Any]):
    """FRAME v99 (Joseph 2026-10-30): on a MIXED claim — the field covering has BOTH an SQ line (slope
    replacement) and an EA line (slope repair) — the comparison row states one SQ figure, the total disturbed
    area (Formula Spec §2.4.2), which no single scope line carries. Mark that row with the facts §5's note
    states, so the renderer appends the sentence (the v93 pattern: the row carries the data). Called only on
    COMPARISON_READY paths. No literal quantity: the comparison figure is the row's own required_quantity; the
    line items are module2_assembly.field_quantities_by_system (the ONE authority, per system — v104e); the repair share is DERIVED from those
    two — the comparison figure less the replacement line (the dual's definition: whole area = replacement +
    repair; field_quantity_agreement_regression holds it to the repair components within 0.0001). Nothing on
    the row is changed; one key is added."""
    if not comparison:
        return comparison
    import types
    from module2_assembly import field_quantities_by_system   # function-local: page 3's import must not register the package (bridge 3)
    # FRAME v104e: PER SYSTEM — bridge 4 retired here. Each system's field covering gets ITS OWN mixed_scope from ITS
    # OWN SQ and EA figures (v104d's field_quantities raises on two systems, by design). With one system this is the
    # v104d computation exactly.
    by_system = field_quantities_by_system(types.SimpleNamespace(aggregated_scope=list(scope_lines or ())))
    if not any("SQ" in {u for _, u in v} and "EA" in {u for _, u in v} for v in by_system.values()):
        return comparison
    fids = field_category_ids()                          # "is this a field covering?" — every system's, none picked
    for line in comparison.get("lines", ()) or ():
        cat = line.get("category_id")
        if cat in fids and line.get("required_unit") == "SQ" and line.get("required_quantity") is not None:
            by_unit = {u: q for q, u in by_system.get(system_for_field_category(cat), ())}   # "whose?" — its own figures
            if "SQ" not in by_unit or "EA" not in by_unit:
                continue
            total = float(line["required_quantity"])
            line["mixed_scope"] = {
                "comparison_quantity": total,
                "replacement_quantity": float(by_unit["SQ"]),
                "repair_quantity": round(total - float(by_unit["SQ"]), 4),
                "line_items": [[float(by_unit["EA"]), "EA"], [float(by_unit["SQ"]), "SQ"]],
            }
    return comparison


def _carrier_view_for_structure(carrier_summary: Mapping[str, Any], structure_id: str) -> Mapping[str, Any]:
    """The carrier approved/excluded/unmapped views narrowed to ONE structure, via the same authority
    the single-structure restrict uses. A structure the carrier never wrote a line for comes back
    empty — every required item then renders MISSING_FROM_CARRIER, which is the argument, not an error."""
    ps = carrier_summary.get("per_structure") or {}
    return {
        "approved": _restrict_to_structure(ps.get("approved") or {}, structure_id, with_audit=False),
        "excluded": _restrict_to_structure(ps.get("excluded") or {}, structure_id, with_audit=True),
        "unmapped": _restrict_to_structure(ps.get("unmapped") or {}, structure_id, with_audit=True),
    }


def build_scope_comparison(module2_result: Any, carrier_summary: Optional[Mapping[str, Any]]) -> Mapping[str, Any]:
    """Build scope comparison from resolved Module 2 and Carrier Parser outputs."""
    if carrier_summary is None:
        required, required_totals = key_and_normalize(
            _required_lines_with_item(_aggregated_scope(module2_result)),
            _system_affected_sf(module2_result),        # FRAME v104d: per system (QA Q1 (a))
        )
        _ops_all, _unres_all = _two_facet_required_operations(module2_result)
        comparison = build_comparison(required, None, required_operations=_ops_all or None)   # inert: no lines
        return {"status": "REQUIRED_SCOPE_ONLY", "required": required,
                "required_totals": required_totals, "scope_comparison": comparison}

    if carrier_summary.get("parser_status") == "NEEDS_CONFIRMATION":
        return {"status": "CARRIER_NEEDS_ESTIMATE_SELECTION",
                "reason": "carrier parser status requires resolved single estimate before comparison",
                "carrier_flags": tuple(carrier_summary.get("flags", ())),
                "duplicate_comparison_categories": tuple(carrier_summary.get("duplicate_comparison_categories", ())),
                "scope_comparison": None}

    required, required_totals = key_and_normalize(
        _required_lines_with_item(_aggregated_scope(module2_result)),
        _system_affected_sf(module2_result),            # FRAME v104d: per system (QA Q1 (a))
    )
    # v72 DEFECT 2: a FULL replacement (every scoped facet replaced, none repaired) flips the required
    # activity code for the non-shake components to REPLACE — they come off with the shakes anyway. A
    # repair or a mixed roof stays R&R for everything (conservative: only a clean full replacement
    # promotes to REPLACE). The always-R&R exceptions are enforced inside build_comparison.
    _repl = list(getattr(module2_result, "replacement_facets", ()) or ()) if not isinstance(module2_result, Mapping) else list(module2_result.get("replacement_facets", ()) or ())
    _rep = list(getattr(module2_result, "repair_facets", ()) or ()) if not isinstance(module2_result, Mapping) else list(module2_result.get("repair_facets", ()) or ())
    is_replacement = bool(_repl) and not _rep

    # PER-STRUCTURE COMPARISON (§5 covers what the USER scoped, not what the carrier scoped).
    # The scoped set is EXACTLY the structures Module 2 built components on (aggregated_scope_by_structure
    # is grouped by each component's facet, and components come only from the user's confirmed events).
    # Fires only with 2+ scoped structures; a single-structure roof (one entry, or an anonymous "")
    # falls straight through to the unchanged single path below and renders byte-identically.
    by_structure = [(str(sid), lines) for sid, lines in _aggregated_scope_by_structure(module2_result) if lines]
    if len(by_structure) >= 2:
        scoped_sids = [sid for sid, _ in by_structure]
        ps = carrier_summary.get("per_structure") or {}
        carrier_structs: set = set()
        for bucket in ("approved", "excluded", "unmapped"):
            carrier_structs |= set((ps.get(bucket) or {}).keys())
        matched = carrier_structs & set(scoped_sids)
        unmatched_carrier = sorted(s for s in carrier_structs if s not in set(scoped_sids))
        scoped_without_carrier = [sid for sid in scoped_sids if sid not in matched]
        # ASK, DO NOT GUESS: carrier lines name buildings that are not among the scoped structures WHILE
        # some scoped structures have no carrier lines at all — the two label sets do not line up (e.g.
        # carrier "Dwelling/Garage" vs geometry "ROOF1/ROOF2"). Comparing across that gap would pit one
        # building's required side against another building's approved side. Withhold and ask instead.
        if unmatched_carrier and scoped_without_carrier:
            return {"status": "CARRIER_NEEDS_STRUCTURE_MAPPING",
                    "reason": "carrier lines name structures that are not among the scoped buildings; "
                              "the structure mapping must be set before a comparison can be built",
                    "unmapped_carrier_structures": unmatched_carrier,
                    "scoped_structures_without_carrier": list(scoped_without_carrier),
                    "required": required, "required_totals": required_totals,
                    "scope_comparison": None}

        aff = _structure_affected_sf(module2_result)
        aff_sys = _structure_system_affected_sf(module2_result)   # FRAME v104d: per structure, per system
        _fallback_sf = _affected_sf(module2_result)
        structure_comparisons = []
        for sid, lines in by_structure:
            req_sid, tot_sid = key_and_normalize(_required_lines_with_item(lines),
                                                 _per_system(aff_sys.get(sid), aff.get(sid, _fallback_sf)))
            carrier_sid = _carrier_view_for_structure(carrier_summary, sid)
            ops_sid, unres_sid = _two_facet_required_operations(module2_result, sid)
            comp_sid = _surface_mixed_scope(_surface_unresolved(
                build_comparison(req_sid, carrier_sid, required_operations=ops_sid or None,
                                 is_replacement=is_replacement), unres_sid), lines)   # v99
            structure_comparisons.append({"structure_id": sid, "scope_comparison": comp_sid,
                                          "required": req_sid, "required_totals": tot_sid})
        # The top-level scope_comparison stays the POOLED comparison so any single-block consumer
        # (shake_dual, required_scope fallbacks) is unchanged; the renderer prefers structure_comparisons.
        # Pooled view: resolved across ALL structures. Two structures that legitimately differ leave the
        # category unresolved HERE only — each structure block above carries its own resolved operation.
        ops_all, _unres_pooled = _two_facet_required_operations(module2_result)
        pooled = build_comparison(required, carrier_summary, required_operations=ops_all or None,
                                  is_replacement=is_replacement)
        return {"status": "COMPARISON_READY", "required": required, "required_totals": required_totals,
                "scope_comparison": pooled, "structure_comparisons": structure_comparisons,
                "scoped_structures": scoped_sids, "multi_structure": True}

    ops_all, unres_all = _two_facet_required_operations(module2_result)
    comparison = _surface_mixed_scope(_surface_unresolved(
        build_comparison(required, carrier_summary, required_operations=ops_all or None,
                         is_replacement=is_replacement), unres_all), _aggregated_scope(module2_result))   # v99
    return {"status": "COMPARISON_READY", "required": required,
            "required_totals": required_totals, "scope_comparison": comparison}
